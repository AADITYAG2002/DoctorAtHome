package com.example.cpy1

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApp()
        }
    }
}

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun MyApp() {
    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text(text = stringResource(id = R.string.app_name)) }) },
            content = { RemoteDataScreen() }
        )
    }
}

@Composable
fun RemoteDataScreen() {
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("") }
    var dataToSend by remember { mutableStateOf("") }
    var dataReceived by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxWidth()) {
        TextField(
            value = host,
            onValueChange = { host = it },
            label = { Text(text = stringResource(id = R.string.host_label)) },
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        )
        TextField(
            value = port,
            onValueChange = { port = it },
            label = { Text(text = stringResource(id = R.string.port_label)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        )
        TextField(
            value = dataToSend,
            onValueChange = { dataToSend = it },
            label = { Text(text = stringResource(id = R.string.data_to_send_label)) },
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        )
        Button(
            onClick = { sendData(host, port.toInt(), dataToSend, { dataReceived = it }, { error = it }) },
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Text(text = stringResource(id = R.string.send_button))
        }
        if (dataReceived.isNotEmpty()) {
            Text(
                text = stringResource(id = R.string.received_data_label, dataReceived),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            )
        }
        if (error.isNotEmpty()) {
            Text(
                text = stringResource(id = R.string.error_label, error),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            )
        }
    }
}

fun sendData(
    host: String,
    port: Int,
    data: String,
    onSuccess: (String) -> Unit,
    onError: (String) -> Unit
) {
    val socket = Socket()
    try {
        socket.connect(InetSocketAddress(host, port), 5000)
        val writer = PrintWriter(BufferedWriter(OutputStreamWriter(socket.getOutputStream())), true)
        val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
        writer.println(data)
        val response = reader.readLine()
        onSuccess(response)
    } catch (e: Exception) {
        onError(e.message ?: "")
    } finally {
        socket.close()
    }
}
fun receiveData(
    port: Int,
    onSuccess: (String) -> Unit,
    onError: (String) -> Unit
) {
    val serverSocket = ServerSocket(port)
    try {
        val socket = serverSocket.accept()
        val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
        val writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream()))
        val receivedData = reader.readLine()
        onSuccess(receivedData)
        writer.write("Data received: $receivedData")
        writer.newLine()
        writer.flush()
    } catch (e: Exception) {
        onError(e.message ?: "")
    } finally {
        serverSocket.close()
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    MyApp()
}
